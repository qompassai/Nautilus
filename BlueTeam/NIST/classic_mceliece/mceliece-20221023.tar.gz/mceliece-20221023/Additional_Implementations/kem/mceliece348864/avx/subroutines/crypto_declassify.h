#ifndef crypto_declassify_h
#define crypto_declassify_h

static void crypto_declassify(void *x,unsigned long long n)
{
}

#endif
