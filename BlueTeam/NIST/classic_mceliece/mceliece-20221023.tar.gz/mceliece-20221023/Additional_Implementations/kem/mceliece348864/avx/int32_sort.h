#ifndef int32_sort_h
#define int32_sort_h

#define int32_sort CRYPTO_NAMESPACE(int32_sort)

#include "crypto_int32.h"

extern void int32_sort(crypto_int32 *,long long);

#endif

